﻿Imports System.Timers



Public Class FormMain
    Dim Int As Integer = 0

    Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim BuildNumber As String = My.Application.Info.Version.Build.ToString
        Me.Text = "Web Browser - Build " + BuildNumber
        FormSettings.HomePageURLBox.Text = My.Settings.HomePage
        Select Case My.Settings.SearchEngine
            Case Is = "Bing"
                FormSettings.BingBox.Checked = True
            Case Is = "Google"
                FormSettings.GoogleBox.Checked = True
            Case Is = "Yahoo"
                FormSettings.YahooBox.Checked = True
        End Select
        Dim WebBrowser As WebBrowser = New WebBrowser
        TabContainer.TabPages.Add("")
        TabContainer.SelectTab(Int)
        WebBrowser.Name = "Web Browser"
        WebBrowser.Dock = DockStyle.Fill
        TabContainer.SelectedTab.Controls.Add(WebBrowser)
        AddHandler WebBrowser.StatusTextChanged, AddressOf Status
        AddHandler WebBrowser.ProgressChanged, AddressOf Loading
        AddHandler WebBrowser.DocumentCompleted, AddressOf Done
        Int = Int + 1
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).ScriptErrorsSuppressed = True
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Navigate(FormSettings.HomePageURLBox.Text)
    End Sub

    Private Sub Status()
        ToolStripStatusLabel1.Text = CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).StatusText
    End Sub

    Private Sub Loading(ByVal sender As Object, ByVal e As Windows.Forms.WebBrowserProgressChangedEventArgs)
        ToolStripProgressBar1.Maximum = e.MaximumProgress
        ToolStripProgressBar1.Value = e.CurrentProgress
    End Sub

    Private Sub Done()
        TabContainer.SelectedTab.Text = CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).DocumentTitle
        AddressBar.Text = CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Url.Host
    End Sub

    Private Sub AddressBar_Click() Handles AddressBar.Click
        AddressBar.Text = CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Url.ToString
    End Sub

    Private Sub AddressBar_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles AddressBar.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Navigate(AddressBar.Text)
        Else
            e.SuppressKeyPress = False
        End If
    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).GoBack()
    End Sub

    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton2.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).GoForward()
    End Sub

    Private Sub ToolStripButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton3.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Stop()
    End Sub

    Private Sub ToolStripButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton4.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Refresh()
    End Sub

    Private Sub ToolStripButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton5.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Navigate(FormSettings.HomePageURLBox.Text)
    End Sub

    Private Sub ToolStripButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton6.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Navigate(AddressBar.Text)
    End Sub

    Private Sub ToolStripButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton7.Click
        If FormSettings.BingBox.Checked = True Then
            CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Navigate("http://www.bing.com/search?q=" + AddressBar.Text)
        ElseIf FormSettings.GoogleBox.Checked = True Then
            CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Navigate("http://www.google.com/search?q=" + AddressBar.Text)
        ElseIf FormSettings.YahooBox.Checked = True Then
            CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Navigate("http://uk.search.yahoo.com/search;_ylt=?p=windows" + AddressBar.Text)
        End If
    End Sub

    Private Sub OpenTabToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenTabToolStripMenuItem.Click
        Dim WebBrowser As WebBrowser = New WebBrowser
        TabContainer.TabPages.Add("")
        TabContainer.SelectTab(Int)
        WebBrowser.Name = "Web Browser"
        WebBrowser.Dock = DockStyle.Fill
        TabContainer.SelectedTab.Controls.Add(WebBrowser)
        AddHandler WebBrowser.StatusTextChanged, AddressOf Status
        AddHandler WebBrowser.ProgressChanged, AddressOf Loading
        AddHandler WebBrowser.DocumentCompleted, AddressOf Done
        Int = Int + 1
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).ScriptErrorsSuppressed = True
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Navigate(FormSettings.HomePageURLBox.Text)
    End Sub

    Private Sub CloseTabToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseTabToolStripMenuItem.Click
        If Not TabContainer.TabPages.Count = 1 Then
            TabContainer.TabPages.RemoveAt(TabContainer.SelectedIndex)
            TabContainer.SelectTab(TabContainer.TabPages.Count - 1)
            Int = Int - 1
        End If
    End Sub

    Private Sub OpenFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFileToolStripMenuItem.Click
        OpenFile.ShowDialog()
    End Sub

    Private Sub OpenFile_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFile.FileOk
        Dim WebPage As String = OpenFile.FileName
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Navigate(WebPage)
    End Sub

    Private Sub OpenFileSystemFolderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFileSystemFolderToolStripMenuItem.Click
        If OpenFolder.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim FileSystemFolder As String = OpenFolder.SelectedPath
            CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).Navigate(FileSystemFolder)
        End If
    End Sub

    Private Sub OpenURLToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenURLToolStripMenuItem.Click
        Dim Form As FormURLEntry = New FormURLEntry
        Form.Show()
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveAsToolStripMenuItem.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).ShowSaveAsDialog()
    End Sub

    Private Sub WebPagePropertiesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WebPagePropertiesToolStripMenuItem.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).ShowPropertiesDialog()
    End Sub

    Private Sub PageSetupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PageSetupToolStripMenuItem.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).ShowPageSetupDialog()
    End Sub

    Private Sub PrintPreviewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintPreviewToolStripMenuItem.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).ShowPrintPreviewDialog()
    End Sub

    Private Sub PrintToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintToolStripMenuItem.Click
        CType(TabContainer.SelectedTab.Controls.Item(0), WebBrowser).ShowPrintDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        End
    End Sub

    Private Sub UndoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UndoToolStripMenuItem.Click
        CType(TabContainer.SelectedTab.Controls(0), WebBrowser).Document.ExecCommand("Undo", False, 1)
    End Sub

    Private Sub RedoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RedoToolStripMenuItem.Click
        CType(TabContainer.SelectedTab.Controls(0), WebBrowser).Document.ExecCommand("Redo", False, 1)
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutToolStripMenuItem.Click
        CType(TabContainer.SelectedTab.Controls(0), WebBrowser).Document.ExecCommand("Cut", False, 1)
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripMenuItem.Click
        CType(TabContainer.SelectedTab.Controls(0), WebBrowser).Document.ExecCommand("Copy", False, 1)
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteToolStripMenuItem.Click
        CType(TabContainer.SelectedTab.Controls(0), WebBrowser).Document.ExecCommand("Paste", False, 1)
    End Sub

    Private Sub InternetOptionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InternetOptionsToolStripMenuItem.Click
        FormSettings.Show()
    End Sub

    Private Sub AddressBar_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles AddressBar.KeyPress
        If e.KeyChar = Convert.ToChar(1) Then
            DirectCast(sender, TextBox).SelectAll()
            e.Handled = True
        End If
    End Sub

    Private Sub UseProxy(ByVal p1 As String)
        Throw New NotImplementedException
    End Sub

End Class
