﻿Public Class Form16

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.esmailelbobpro.tk/p/store.html#!/Folder-Locker-serial/p/88448753/category=0") ' vb.net
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.esmailelbobpro.tk/p/store.html#!/Encrypt-word-serial/p/88448744/category=0") ' vb.net
    End Sub
End Class