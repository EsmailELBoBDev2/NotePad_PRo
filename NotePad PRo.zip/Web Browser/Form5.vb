﻿Public Class Form5

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Updates Button
        MessageBox.Show("I Update The Program Weekly")
        MessageBox.Show("I Will Add Program With Date To Know You Have Old Version Or No")
        Process.Start("http://netb.ee/notepadpro") ' vb.net
        Me.Hide()
        Form3.Show()
    End Sub
End Class