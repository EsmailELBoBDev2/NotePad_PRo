﻿Public Class FormSettings

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub FormSettings_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        HomePageURLBox.Text = My.Settings.HomePage
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim HomePageSetting As New My.MySettings
        HomePageSetting.HomePage = HomePageURLBox.Text
        HomePageSetting.Save()
        MessageBox.Show("Done!, Restart The Project To Apply It :)")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If BingBox.Checked = True Then
            Dim SearchEngineSetting As New My.MySettings
            SearchEngineSetting.SearchEngine = "Bing"
            SearchEngineSetting.Save()
        ElseIf GoogleBox.Checked = True Then
            Dim SearchEngineSetting As New My.MySettings
            SearchEngineSetting.SearchEngine = "Google"
            SearchEngineSetting.Save()
        ElseIf YahooBox.Checked = True Then
            Dim SearchEngineSetting As New My.MySettings
            SearchEngineSetting.SearchEngine = "Yahoo"
            SearchEngineSetting.Save()
        End If
        MessageBox.Show("Done!, Restart The Project To Apply It :)")
    End Sub

    Private Sub HomePageURLBox_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles HomePageURLBox.KeyPress
        If e.KeyChar = Convert.ToChar(1) Then
            DirectCast(sender, TextBox).SelectAll()
            e.Handled = True
        End If
    End Sub
End Class