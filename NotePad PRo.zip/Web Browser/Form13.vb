﻿Public Class Form13
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        If TextBox1.Text = "Esmail EL BoB" Then
            TextBox2.Text = "&cUMebm^_t*74N&dW5m+RYrDjRasbNKvWgdex@Tx+tXq#3VqR_2c8Wz=EKd^+Hrw&q6Ndh?+T8AxDwntH8xLmv2k#_wrQGXtE%L$BkVS4gutSnnYYK5xSm?sRS+k5H-9A=J9Dq?WWw+rP!qZzNwnkscqRA*N-mmhK%2%kXw68ESaGDtysC8%@%jz#a%RJ4VSy5t!g+4mQJc@qn&nM8SkzFvRGk%%KN6JUKwS&Y-Dk2LuZ@TZx_MEVRz=px7Sw3D%u6fDAPG^v^2yA8BKSXt2KNAccX6vaehnC3w-?XrVfKYzzpP4*wGnbS-U$yDA&kwD-V&QZ&bswUFPsgQm+wyvnY_^PRV?fA#CjAEY-pEv2-dTWLd&5&^#NXZ9H3%=rGkVwWpUngk_ZL#uC3%WrDV8CHrrEzjCpKS%*UEEY6NpuFxBbSL&8w*LT$TQxTj&cHb!gJzk3_XZfE-+pLsDDd7^X&KUvms2RR+kn*&^fWzy9TnRqPBWnds!dQKqarY=BQS4Hr*w$%Tx%wNzKD6DJeLGP&?LG!t76Uu-K%_Uff?tBf-Wr#ZP&aQ2VBYgH5Sw2wZ^AATYUQ@xMszbMDWhZ%8Jk8E^GJgwfT^eZcK+gHcNKQjqTxHfxEY8=DcQVDXY^Rp5Ge5@SeL4pn8qA5gs+fTkvz4jubm$^ZE^WWt!fma6v6Nb-45A=atu7R7gLQv*wTxQceMUUxsAKc5r&+hBkj=^dAw+4DLCubEY^*yU9B?NTphqcW8WvQ_K6*6M^PeLRV$wy%azn@DGqL3*-=2kR7&$y*q2WGTGuxY&!+Hn9hnXs#@8b&Dh@DpzeX+$79Bfz$pY-8F$NNuAZ8&ch^JL-fD@nxgfvEkU9K6ryKv-P&UPb#Xq8EA*Bhm8!_aXx_GtsQafN3at6vW-?Q?3jSqYh=wJKgAqb?@A%VCL9dPt&saLd3fw%!FvXDmmju^hr?L?&yApa+uZVP#vs-Yu&4wj4TS__ULfBbaSKwudXrGD-$!^^EU#TfybH%8tBY-h2UxUg!M^F-c%*52r^BMrG=E&6QQvSd^u6T9wPQcK5QpvGfFb^zeLBb*pUKWmZA+hKv95bkwKJ33@4@EkWLy*G5nX6gw%_Y_=4@XGL$AV2Q_Pgjzf=VTYDCCuTYtUXF6u6jJg7QjNgxX+2P&SGuNF8FCzBV#TmhE&bG6W?Nhcjn7PDRLx!pp3qqDSG6&7r@A?3etCHNAGv_k2hrrt&bYyasTxGVZcbJ_w9K#VqaK@%ce5qZTH#Pn95QG$7TR?c=CX$^6QxJ$=M?xnv$rUz%&8GyymskGCxJY%6qGW&vD$Cx5%7E95A5=J8vW=pS&sxdApNkf?UfSJRVP@W4^WzUzSg6mhrm^&Pz#YJyjXN=eXzwwE9z_+@4PCeL^Hz-8P@4ksVE3gymh5YBb^XhaLDnNKfXH=Az_QLf_tHEK==J2?VN+z??xrJEvgZ6-$YF=MfpZqVN9DUEvKeetW2Ub=HXhSDF8?6f$_?-Yy3m!%#=bTXsmKcmz72W_9bJ+Fa95yH-n5F3R#u3z8^mrRtCCX6qdwUR!&4@8!2mG@*Gs$Xv?4rke3y7fPbh2$f@WRgXU=m$?Yr$TA$WJfDsdcq#QtF=+A?^RJ#M??zk&C6#w-MU4?@Pyum7S2jJ4aCTRxy9L6xEctPKPCV4UfQQbrUWBg$_4P9*4L_AG778cJN$9=U-EKh%k+teZLN_*JL@@D9LZVK_uKkPfSd+hHXxQj*K9-V?A^myzJpaAKcRmG@T-?7c%vRxpf*@3c^-@Nx!jZRxLuB&n5v&F5_@gmcHQVfPQeFDmT$p$vWnm7J32M?CeEDdxj#7kbUmv3qRkcbSHrH@2ep6LVCR774xqQDEX$=_cW5yy_Py&PWpk$5_GbKuBss4e@E%t-$p@nvW&umPm+eP#TjXG@McC!X+#^!WFW$4B4-AmPHfZPd8G&$8vj4rDB_sdk#$sR^CPq#73$q5n^WSXX++-r-vCP&LuYe-8=Fj_a9%Qm_TyT3$yB^tZ=Aq_2w*pq3f?^42csBQbwKSZCze6eyz*TPu4v?hTx"
            TextBox3.Text = "f5%=Hd3us-Jd8gQtx3UfZM7CzB3XQPmkGWz5Wf?7^zs2k!xL+7rgCe+jLFyvJqA3KY2u^B_t?5=mF%fthpkbYe##3Pg_L*^kvH7EQeHnC!_j2PqfhL9nswQTqv7da%C6A7=YNHn5RB59V!GhwrPnwWq=fpTb8&kL-wuX^SePLV_^?MEBG3HDQ9!!Z+5EctBnJs@%ecD@5&*KwqdDX^^#QR^R!D_A4u?CxWtQ$3+me8f9ptcLX#2ZU6A_4#X27AGR&tqhEJ2Kx^!fHB8DB?mX-uXfCh7mCR-=h8F__43b%f7?U-zBpqatfQt_jH=x%#dxtNkrA@Htaa2yz%uBR#F9bA^VxA?Sh7HQkqEqYkRaCqagEdrPnt%C$sWVa58CeK&4MR3!+nSYt4j%%uPMmJGERdQNGHAhjbp^?*uEXLN!!=Su_^WD2!5rkqPN4zBA8tHg9*8pWcE@ftazZ5vdpW56JCQmfdBxj5yH#T%3QUmTHM77wn%Gwk*XnbRAewm%F@vxfypxFB^UA_@a+qN@4Mj-&#W?%9nJCmEFxD?KbZ7jGuUa3nQa?Zp!pg78!SR8j#NVQ3WA*fBf4%LKhsnX6cD6XDu@@84UZYH!RFHaM8fQ+J=F$ba-aDhfV$v98*E9wRaM2%hK$BF3PL5nJfxhaUN$hmEY_bB3vwGJuX8dbAkZUw*eCWKzS&&^%D@R&=Q?u!d%nr&q7dF3EZJPV*#agpt$e=q6%rrMBKCMr^7eY@+-3RASp$?y+RW3^j9E#QPF4LG%cwLwBvhMfc!RDd+6aH$Mh6$e9K%dRRB#HN*@ARbLxx=pFnMn2SPu*LXdjV?-H-+2AjxR$ccn-@C5P^evLR#&mH9ZcKAMrZS6P$#7_G?CMFb9t2=^tBpLF*@yKNf38bx4kKN7Zv6Mmx5-6eajfx@wuN-KNDzBegfrqTU3ga#W$kwG8&CXqV=aFA7ktg?E_AFzZ8BwqH4Et-ptD_t3R^XUHs3!vye2Ug2bZdWcjprD8wE@!Vf+!Q*tgutyM3!^?-nGf$zR%UX+W$TH!ack+Q6kRxzTmJt+CeSBjcwuGx3h3at*P%ZSbEW--$AwUMKkPrQWk?&qCrcY5-USMnP!r8LQ=c$@2PCC%5u38xCrcEQQ#+dWW^QFBXQj-J!6UuupB2WCRSGtSJB^SBJN%zq@XCex6?XA^J479KvjMzeQ2^uAzZeeXV4dTd4mdg#c34-Uy8#!F6ueZg-3@B3gH?vR!74NVRT+4kUJxXvb2#8R^7%rsH^wUm+_M$D-a7Y+EK^F$WPRuZQu5aqeHqZv@wCy-M-$buddJmA5nM_pT?mWjJEu6D9g5ju&2DJbf$JhkA+Azs@yA@8MMt^PzpPLs=pp6QHe6PAXc6WxAvs3URZ*2tdSbHnCsjEqc73rDuCWNU!YrGjGQmD^6!_Z-4Z2$@@xSuRYaA8Hrp?B^SWVs_5%AW_#ffUNabU#FSPpbM+83u%CDVZK##NmVk%$K+q!QD$6g==jZw7TPb&_bEL?&&B&S&L+KE57=RGV%%-3=$=cbMZ&_sDS5JUHy2gF_us-gW-5B@^%D#evk-^wxAhF=GFFfNm3g9rJt3TN$B2mtdpfnFWXNfPtswU*MMD_tT@tSN9M7BhJ3cYMK+ymM6d7vjaMjn+u!u!93gtjtWF8*@+tU=VtbVuCsqk7*_^v*nqRVMGNqA7QS83a7Xp8?fAJhVYBemy3M3xD@f3&wTp-$%^+Uf@m#$r2XRMgWnST2Rr-6@&Eq^cny_XkAsZzBx47Vq+Lr5SWWeb$gNGx5ZBFyxM%B&bSgpVTBrZQ4*Z&QsL^MDBxspYustV3S?6uDw*Xf2HPJCymDkG$xXbnkxN?tLZZP8Eg2wgYDd57kb=u8q+E2CY^5V!L^3XA9#3NXnQTu9@rejZrZgBHBL*n@kehyyV$*4^VqUF^nb?mAw7eVnaek4jfc-55vsQ&KA-qSz+MxUuwqZ$LRDf4ZC#Bx8XsHaxpeW$v!Yw878vcMqhWpxnbwSeFG^bNSKP=n3msnr!D+KqH7a^6kTH4x&#Y-j-Az+GNXuKCyfpb"
        End If

    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Form14.Show()
        Me.Hide()
    End Sub
    Private Sub Form13_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim BuildNumber As String = My.Application.Info.Version.Build.ToString
        Me.Text = "Login Screen - Build Number " + BuildNumber
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Convert.ToChar(1) Then
            DirectCast(sender, TextBox).SelectAll()
            e.Handled = True
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If TextBox1.Text = "Esmail EL BoB" Then
            Form2.Show()
            Me.Hide()
        End If
        If TextBox1.Text = "PotatoMan117" Then
            MessageBox.Show("please visit signup page to renew your info")
            Process.Start("https://goo.gl/forms/0Na4KMKJx1Ukm2Y52") ' vb.net
            Form2.Show()
            Me.Hide()
        End If
        If TextBox1.Text = "1Glaicer1" Then
            MessageBox.Show("please visit signup page to renew your info")
            Process.Start("https://goo.gl/forms/0Na4KMKJx1Ukm2Y52") ' vb.net
            Form2.Show()
            Me.Hide()
        End If
        If TextBox1.Text = "early" Then
            MessageBox.Show("please visit signup page to renew your info")
            Process.Start("https://goo.gl/forms/0Na4KMKJx1Ukm2Y52") ' vb.net
            Form2.Show()
            Me.Hide()
        End If
        If TextBox1.Text = "Beaudu" Then
            MessageBox.Show("please visit signup page to renew your info")
            Process.Start("https://goo.gl/forms/0Na4KMKJx1Ukm2Y52") ' vb.net
            Form2.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Form16.Show()
    End Sub
End Class
