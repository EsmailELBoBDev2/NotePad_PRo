﻿Imports IWshRuntimeLibrary
Public Class Form15
    Private Sub CheckBox1_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        'Agree Check Box
        Form13.Show()
        Me.Hide()
    End Sub
    Private Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        'Exit Button
        End
    End Sub
    Private Sub LinkLabel1_LinkClicked_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("https://goo.gl/forms/lcRepQKVWn3xufVy1") ' vb.net
    End Sub
    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        'Disagree Check Box
        End
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'About Button
        MessageBox.Show("Dev By: Esmail EL BoB")
        MessageBox.Show("[BETA] [Built In --> 1/July/2017]")
        MessageBox.Show("Current version: 0.0.1.9    \   Next Version: 0.0.1.10")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'Bug Button
        Process.Start("https://goo.gl/forms/QcJu8hMWQlUcut3v2") ' vb.net
    End Sub
End Class
