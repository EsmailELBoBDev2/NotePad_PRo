﻿
Class fromproxy

End Class
