﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormSettings))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.HomePageTab = New System.Windows.Forms.TabPage()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.HomePageURLBox = New System.Windows.Forms.TextBox()
        Me.SearchEngineTab = New System.Windows.Forms.TabPage()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.YahooBox = New System.Windows.Forms.RadioButton()
        Me.GoogleBox = New System.Windows.Forms.RadioButton()
        Me.BingBox = New System.Windows.Forms.RadioButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.HomePageTab.SuspendLayout()
        Me.SearchEngineTab.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.HomePageTab)
        Me.TabControl1.Controls.Add(Me.SearchEngineTab)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(311, 102)
        Me.TabControl1.TabIndex = 0
        '
        'HomePageTab
        '
        Me.HomePageTab.BackColor = System.Drawing.Color.Black
        Me.HomePageTab.Controls.Add(Me.Button2)
        Me.HomePageTab.Controls.Add(Me.Label1)
        Me.HomePageTab.Controls.Add(Me.HomePageURLBox)
        Me.HomePageTab.ForeColor = System.Drawing.Color.White
        Me.HomePageTab.Location = New System.Drawing.Point(4, 22)
        Me.HomePageTab.Name = "HomePageTab"
        Me.HomePageTab.Padding = New System.Windows.Forms.Padding(3)
        Me.HomePageTab.Size = New System.Drawing.Size(303, 76)
        Me.HomePageTab.TabIndex = 0
        Me.HomePageTab.Text = "Home Page"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Black
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(222, 45)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Save"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "URL:"
        '
        'HomePageURLBox
        '
        Me.HomePageURLBox.Location = New System.Drawing.Point(9, 19)
        Me.HomePageURLBox.Name = "HomePageURLBox"
        Me.HomePageURLBox.Size = New System.Drawing.Size(288, 20)
        Me.HomePageURLBox.TabIndex = 0
        '
        'SearchEngineTab
        '
        Me.SearchEngineTab.BackColor = System.Drawing.SystemColors.WindowText
        Me.SearchEngineTab.Controls.Add(Me.Button3)
        Me.SearchEngineTab.Controls.Add(Me.YahooBox)
        Me.SearchEngineTab.Controls.Add(Me.GoogleBox)
        Me.SearchEngineTab.Controls.Add(Me.BingBox)
        Me.SearchEngineTab.Controls.Add(Me.Label2)
        Me.SearchEngineTab.Location = New System.Drawing.Point(4, 22)
        Me.SearchEngineTab.Name = "SearchEngineTab"
        Me.SearchEngineTab.Padding = New System.Windows.Forms.Padding(3)
        Me.SearchEngineTab.Size = New System.Drawing.Size(303, 76)
        Me.SearchEngineTab.TabIndex = 1
        Me.SearchEngineTab.Text = "Search Engine"
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button3.ForeColor = System.Drawing.Color.Cornsilk
        Me.Button3.Location = New System.Drawing.Point(222, 42)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Save"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'YahooBox
        '
        Me.YahooBox.AutoSize = True
        Me.YahooBox.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.YahooBox.ForeColor = System.Drawing.Color.Cornsilk
        Me.YahooBox.Location = New System.Drawing.Point(169, 19)
        Me.YahooBox.Name = "YahooBox"
        Me.YahooBox.Size = New System.Drawing.Size(59, 17)
        Me.YahooBox.TabIndex = 3
        Me.YahooBox.Text = "Yahoo!"
        Me.YahooBox.UseVisualStyleBackColor = False
        '
        'GoogleBox
        '
        Me.GoogleBox.AutoSize = True
        Me.GoogleBox.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GoogleBox.ForeColor = System.Drawing.Color.Cornsilk
        Me.GoogleBox.Location = New System.Drawing.Point(104, 19)
        Me.GoogleBox.Name = "GoogleBox"
        Me.GoogleBox.Size = New System.Drawing.Size(58, 17)
        Me.GoogleBox.TabIndex = 2
        Me.GoogleBox.Text = "Google"
        Me.GoogleBox.UseVisualStyleBackColor = False
        '
        'BingBox
        '
        Me.BingBox.AutoSize = True
        Me.BingBox.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BingBox.Checked = True
        Me.BingBox.ForeColor = System.Drawing.Color.Cornsilk
        Me.BingBox.Location = New System.Drawing.Point(9, 19)
        Me.BingBox.Name = "BingBox"
        Me.BingBox.Size = New System.Drawing.Size(90, 17)
        Me.BingBox.TabIndex = 1
        Me.BingBox.TabStop = True
        Me.BingBox.Text = "Bing - Default"
        Me.BingBox.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.ForeColor = System.Drawing.Color.Cornsilk
        Me.Label2.Location = New System.Drawing.Point(6, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Search Providers:"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button1.ForeColor = System.Drawing.Color.Cornsilk
        Me.Button1.Location = New System.Drawing.Point(248, 120)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "OK"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'FormSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(337, 153)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormSettings"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Internet Options"
        Me.TopMost = True
        Me.TabControl1.ResumeLayout(False)
        Me.HomePageTab.ResumeLayout(False)
        Me.HomePageTab.PerformLayout()
        Me.SearchEngineTab.ResumeLayout(False)
        Me.SearchEngineTab.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents HomePageTab As System.Windows.Forms.TabPage
    Friend WithEvents SearchEngineTab As System.Windows.Forms.TabPage
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents HomePageURLBox As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents YahooBox As System.Windows.Forms.RadioButton
    Friend WithEvents GoogleBox As System.Windows.Forms.RadioButton
    Friend WithEvents BingBox As System.Windows.Forms.RadioButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
