﻿Public Class Form16

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Process.Start("https://goo.gl/forms/QcJu8hMWQlUcut3v2") ' vb.net
        Me.Hide()
    End Sub
End Class