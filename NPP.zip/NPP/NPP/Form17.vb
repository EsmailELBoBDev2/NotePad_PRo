﻿Public Class Form17

    Private Sub Form17_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (UsernameTextBox.Text = "Esmail") And (PasswordTextBox.Text = "") Then

            MessageBox.Show("Welcome Owner")
            Form2.Show()
            Me.Hide()

        ElseIf (UsernameTextBox.Text = "") Then

            MessageBox.Show("Write The Username!")

        ElseIf (PasswordTextBox.Text = "") Then

            MessageBox.Show("Write The Password!")

        ElseIf (UsernameTextBox.Text = "PotatoMan117") And (PasswordTextBox.Text = "HotCatTheHotDog") Then

            MessageBox.Show("Welcome 117isthename@gmail.com")
            Form2.Show()
            Me.Hide()

        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)

    End Sub

    Private Sub LinkLabel1_LinkClicked_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        MessageBox.Show("You will need to go on the website to add your Username & Password so that i could add it to the project, then press Ok! :D")
        Process.Start("https://goo.gl/forms/lcRepQKVWn3xufVy1") ' vb.net
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class