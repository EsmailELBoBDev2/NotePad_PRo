﻿Public Class Form11

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Process.Start("https://esmailelbobforgamed.blogspot.com") ' vb.net
        Process.Start("https://esmailelbob.wixsite.com/esmailelbob") ' vb.net
        Me.Hide()
    End Sub
End Class