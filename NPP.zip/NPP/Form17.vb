﻿Public Class Form17
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (UsernameTextBox.Text = "Esmail") Then

            MessageBox.Show("Welcome Owner")
            Form2.Show()
            Me.Hide()


        ElseIf (UsernameTextBox.Text = "PotatoMan117") Then

            MessageBox.Show("Welcome 117isthename@gmail.com")
            Form2.Show()
            Me.Hide()



        End If



    End Sub
    Private Sub LinkLabel1_LinkClicked_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        MessageBox.Show("You will need to go on the website to add your Username & Password so that i could add it to the project, press Ok! :D")
        Process.Start("https://goo.gl/forms/lcRepQKVWn3xufVy1") ' vb.net
    End Sub
    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        MessageBox.Show("My Discord To Send Me Message With Your E-mail, Press Ok! :D")
        Process.Start("https://discord.gg/XTZjdSp") ' vb.net
    End Sub

    Private Sub UsernameTextBox_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles UsernameTextBox.KeyDown
        If e.KeyCode = Keys.F13 Then

        ElseIf (UsernameTextBox.Text = "Esmail") Then

            MessageBox.Show("Welcome Owner")
            Form2.Show()
            Me.Hide()


        ElseIf (UsernameTextBox.Text = "PotatoMan117") Then

            MessageBox.Show("Welcome 117isthename@gmail.com")
            Form2.Show()
            Me.Hide()


        ElseIf (UsernameTextBox.Text = "1Glaicer1") Then

            MessageBox.Show("Welcome alonkiller2016@gmail.com")
            Form2.Show()
            Me.Hide()


        ElseIf (UsernameTextBox.Text = "early") Then

            MessageBox.Show("Welcome yehseen123@gmail.com")
            Form2.Show()
            Me.Hide()


        End If

    End Sub

    Private Sub UsernameTextBox_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles UsernameTextBox.KeyPress

        If e.KeyChar = Convert.ToChar(1) Then
            DirectCast(sender, TextBox).SelectAll()
            e.Handled = True
        End If



    End Sub
    Private Sub Button1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Button1.KeyDown

        If e.KeyCode = Keys.Enter Then
            Form2.Show()
        End If
    End Sub
End Class

