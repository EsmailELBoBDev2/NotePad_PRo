﻿Public Class Form5

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MessageBox.Show("I will open Monday from the first sites to know what is the version of your hand and the second to download the program (if your version is old)")
        Process.Start("https://esmailelbobforgamed.blogspot.com.eg/p/update.html") ' vb.net
        Process.Start("http://netb.ee/notepadpro") ' vb.net
        Me.Hide()
        Form3.Show()

    End Sub
End Class