﻿Public Class Form18

    Public Sub AddTab(ByRef URL As String, ByRef TabControl As TabControl)
        Dim NewBrowser As New custombrowser
        Dim NewTab As New TabPage
        NewBrowser.Tag = NewTab
        NewTab.Tag = NewBrowser
        TabControl.TabPages.Add(NewTab)
        NewTab.Controls.Add(NewBrowser)
        NewBrowser.Dock = DockStyle.Fill
        NewBrowser.Navigate(URL)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Dim WB As custombrowser = Me.TabControl1.SelectedTab.Tag
        WB.Refresh()

    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnForward.Click
        Dim WB As custombrowser = Me.TabControl1.SelectedTab.Tag
        WB.GoForward()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Dim WB As custombrowser = Me.TabControl1.SelectedTab.Tag
        WB.GoBack()

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
        Dim WB As custombrowser = Me.TabControl1.SelectedTab.Tag
        WB.Stop()
    End Sub
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim WB As custombrowser = Me.TabControl1.SelectedTab.Tag
        WB.Navigate(Me.cbURL.Text)
        cbURL.Items.Add(cbURL.Text)

    End Sub

    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged
        Dim WB As custombrowser = Me.TabControl1.SelectedTab.Tag
        Me.cburl.text = WB.Url.ToString

    End Sub

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        If TabControl1.TabPages.Count = 1 Then
            Me.Close()
        Else
            TabControl1.TabPages.Remove(TabControl1.SelectedTab)
        End If
    End Sub

    Private Sub btnAddTab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddTab.Click
        AddTab("about:blank", TabControl1)
    End Sub

    Private Sub cbURL_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cbURL.KeyDown
        If e.KeyCode = Keys.F13 Then

        Else

            Dim WB As custombrowser = Me.TabControl1.SelectedTab.Tag
            WB.Navigate(Me.cbURL.Text)
            cbURL.Items.Add(cbURL.Text)


        End If
    End Sub

    Private Sub cbURL_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cbURL.KeyPress
        If e.KeyChar = Convert.ToChar(1) Then
            DirectCast(sender, ComboBox).SelectAll()
            e.Handled = True
        End If
    End Sub
    Private Sub cbgoogle_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cbgoogle.KeyDown
        If e.KeyCode = Keys.F13 Then

        Else

            Dim WB As custombrowser = Me.TabControl1.SelectedTab.Tag
            WB.Navigate("http://www.google.com/search?q=" + cbgoogle.Text)


        End If
    End Sub

    Private Sub cbgoogle_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cbgoogle.KeyPress
        If e.KeyChar = Convert.ToChar(1) Then
            DirectCast(sender, ComboBox).SelectAll()
            e.Handled = True
        End If
    End Sub

    Private Sub Form18_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class


Public Class custombrowser
    Inherits WebBrowser

    Public Sub New()
        Me.ScriptErrorsSuppressed = True

    End Sub

    Private Sub DocCompleted() Handles Me.DocumentCompleted
        Dim TP As TabPage = Me.Tag
        If Me.DocumentTitle.Length > 15 Then
            TP.Text = Me.DocumentTitle.Substring(0, 14) & "..."
        Else
            TP.Text = Me.DocumentTitle
        End If
    End Sub
End Class