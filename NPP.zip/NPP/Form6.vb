﻿Public Class Form6

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim result As DialogResult
        result = MessageBox.Show("Are You Sure You Want Open This Link ?", "Open Discord Link", MessageBoxButtons.YesNo)
        If result = DialogResult.No Then
            Me.Hide()
        ElseIf result = DialogResult.Yes Then
            Process.Start("https://discord.gg/wus7H") ' vb.net
            Me.Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim result As DialogResult
        result = MessageBox.Show("Are You Sure You Want Open This Link ?", "Open twitch Link", MessageBoxButtons.YesNo)
        If result = DialogResult.No Then
            Me.Close()
        ElseIf result = DialogResult.Yes Then
            Process.Start("https://invite.twitch.tv/CYv1vN") ' vb.net
            Me.Close()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim result As DialogResult
        result = MessageBox.Show("Are You Sure You Want Open This Link ?", "Open Instagram Link", MessageBoxButtons.YesNo)
        If result = DialogResult.No Then
            Me.Close()
        ElseIf result = DialogResult.Yes Then
            Process.Start("https://instagram.com/esmailelbob01") ' vb.net
            Me.Close()
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim result As DialogResult
        result = MessageBox.Show("Are You Sure You Want Open This Link ?", "Open My Websites Link", MessageBoxButtons.YesNo)
        If result = DialogResult.No Then
            Me.Hide()
        ElseIf result = DialogResult.Yes Then
            Process.Start("https://esmailelbobforgamed.blogspot.com") ' vb.net
            Process.Start("https://esmailelbob.wixsite.com/esmailelbob") ' vb.net
            Me.Close()
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        MessageBox.Show("Comming Soon")
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim result As DialogResult
        result = MessageBox.Show("Are You Sure You Want Open This Link ?", "Open Github Link", MessageBoxButtons.YesNo)
        If result = DialogResult.No Then
            Me.Hide()
        ElseIf result = DialogResult.Yes Then
            Process.Start("https://github.com/EsmailELBoBDev2/NotePad_PRo/") ' vb.net
            Me.Close()
        End If
    End Sub
   Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim result As DialogResult
        result = MessageBox.Show("Are You Sure You Want Open This Link ?", "Open YT Link", MessageBoxButtons.YesNo)
        If result = DialogResult.No Then
            Me.Hide()
        ElseIf result = DialogResult.Yes Then
            Process.Start("https://www.youtube.com/channel/UCJleo-8bSe7NUKXLWf-xQww") ' vb.net
            Me.Close()
        End If
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim result As DialogResult
        result = MessageBox.Show("Are You Sure You Want Open This Link ?", "Open FB Link", MessageBoxButtons.YesNo)
        If result = DialogResult.No Then
            Me.Hide()
        ElseIf result = DialogResult.Yes Then
            Process.Start("https://fb.com/esmailelbob01") ' vb.net
            Me.Close()
        End If
    End Sub
End Class