﻿Imports IWshRuntimeLibrary
Public Class Form15
    Private Sub CheckBox1_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        Form17.Show()
        Me.Hide()
    End Sub
    Private Sub LinkLabel1_LinkClicked_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("https://goo.gl/forms/lcRepQKVWn3xufVy1") ' vb.net
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        MessageBox.Show("Thx :) & please wait")
        'Create path variables 
        Dim startupPath As String = Environment.GetFolderPath(Environment.SpecialFolder.Startup)
        Dim executablePath As String = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName
        Dim executabelName As String = System.Diagnostics.Process.GetCurrentProcess().MainModule.ModuleName
        'create shortcut
        Dim Shell As WshShell
        Dim Link As WshShortcut
        Try
            Shell = New WshShell
            Link = CType(Shell.CreateShortcut(startupPath & "\" & executabelName & ".lnk"), IWshShortcut)
            Link.TargetPath = executablePath
            Link.Save()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        MessageBox.Show("Done!")
    End Sub

    Private Sub RadioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        Dim startupPath As String = Environment.GetFolderPath(Environment.SpecialFolder.Startup)
        Dim executableName As String = System.Diagnostics.Process.GetCurrentProcess().MainModule.ModuleName

        Dim directoryInfo As New System.IO.DirectoryInfo(startupPath)
        Dim fileinfo() As System.IO.FileInfo
        fileinfo = directoryInfo.GetFiles("*.lnk")
        For Each file As System.IO.FileInfo In fileinfo
            If (file.FullName.Contains(executableName)) Then
                file.Delete()
            End If
        Next

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        End
    End Sub
End Class