﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form18
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form18))
        Me.cbURL = New System.Windows.Forms.ComboBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.cbgoogle = New System.Windows.Forms.ComboBox()
        Me.btnAddTab = New System.Windows.Forms.Button()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnForward = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cbURL
        '
        Me.cbURL.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cbURL.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.cbURL.ForeColor = System.Drawing.Color.White
        Me.cbURL.FormattingEnabled = True
        Me.cbURL.Items.AddRange(New Object() {"Google.com"})
        Me.cbURL.Location = New System.Drawing.Point(230, 23)
        Me.cbURL.Name = "cbURL"
        Me.cbURL.Size = New System.Drawing.Size(546, 21)
        Me.cbURL.TabIndex = 6
        Me.cbURL.Text = "Website Link"
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Location = New System.Drawing.Point(12, 59)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1103, 676)
        Me.TabControl1.TabIndex = 10
        '
        'cbgoogle
        '
        Me.cbgoogle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cbgoogle.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.cbgoogle.ForeColor = System.Drawing.Color.White
        Me.cbgoogle.FormattingEnabled = True
        Me.cbgoogle.Items.AddRange(New Object() {"Youtube"})
        Me.cbgoogle.Location = New System.Drawing.Point(782, 23)
        Me.cbgoogle.Name = "cbgoogle"
        Me.cbgoogle.Size = New System.Drawing.Size(244, 21)
        Me.cbgoogle.TabIndex = 12
        Me.cbgoogle.Text = "Google Search"
        '
        'btnAddTab
        '
        Me.btnAddTab.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAddTab.BackColor = System.Drawing.Color.Gray
        Me.btnAddTab.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAddTab.ForeColor = System.Drawing.Color.White
        Me.btnAddTab.Image = Global.NotePadPRo.My.Resources.Resources._1497473745_plus_add_more_detail
        Me.btnAddTab.Location = New System.Drawing.Point(1032, 14)
        Me.btnAddTab.Name = "btnAddTab"
        Me.btnAddTab.Size = New System.Drawing.Size(39, 37)
        Me.btnAddTab.TabIndex = 8
        Me.btnAddTab.UseVisualStyleBackColor = False
        '
        'btnRemove
        '
        Me.btnRemove.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRemove.BackColor = System.Drawing.Color.Gray
        Me.btnRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRemove.ForeColor = System.Drawing.Color.White
        Me.btnRemove.Image = Global.NotePadPRo.My.Resources.Resources._1497452330_less
        Me.btnRemove.Location = New System.Drawing.Point(1077, 14)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(38, 37)
        Me.btnRemove.TabIndex = 7
        Me.btnRemove.UseVisualStyleBackColor = False
        '
        'btnStop
        '
        Me.btnStop.BackColor = System.Drawing.Color.Gray
        Me.btnStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStop.ForeColor = System.Drawing.Color.White
        Me.btnStop.Image = Global.NotePadPRo.My.Resources.Resources._1497452299_close
        Me.btnStop.Location = New System.Drawing.Point(177, 12)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(47, 41)
        Me.btnStop.TabIndex = 5
        Me.btnStop.UseVisualStyleBackColor = False
        '
        'btnRefresh
        '
        Me.btnRefresh.BackColor = System.Drawing.Color.Gray
        Me.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefresh.ForeColor = System.Drawing.Color.White
        Me.btnRefresh.Image = Global.NotePadPRo.My.Resources.Resources._1497452170_Update
        Me.btnRefresh.Location = New System.Drawing.Point(122, 12)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(49, 41)
        Me.btnRefresh.TabIndex = 2
        Me.btnRefresh.UseVisualStyleBackColor = False
        '
        'btnForward
        '
        Me.btnForward.BackColor = System.Drawing.Color.Gray
        Me.btnForward.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnForward.ForeColor = System.Drawing.Color.White
        Me.btnForward.Image = Global.NotePadPRo.My.Resources.Resources._1497452147_Arrow_Forward
        Me.btnForward.Location = New System.Drawing.Point(67, 12)
        Me.btnForward.Name = "btnForward"
        Me.btnForward.Size = New System.Drawing.Size(49, 41)
        Me.btnForward.TabIndex = 1
        Me.btnForward.UseVisualStyleBackColor = False
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Gray
        Me.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Image = Global.NotePadPRo.My.Resources.Resources._1497473929_Arrow_Back
        Me.btnBack.Location = New System.Drawing.Point(12, 12)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(49, 41)
        Me.btnBack.TabIndex = 0
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'Form18
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(1120, 771)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.btnAddTab)
        Me.Controls.Add(Me.btnRemove)
        Me.Controls.Add(Me.btnStop)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.btnForward)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.cbgoogle)
        Me.Controls.Add(Me.cbURL)
        Me.ForeColor = System.Drawing.Color.White
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form18"
        Me.Text = "Browser - NotePad PRo"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnBack As System.Windows.Forms.Button
    Friend WithEvents btnForward As System.Windows.Forms.Button
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnStop As System.Windows.Forms.Button
    Friend WithEvents cbURL As System.Windows.Forms.ComboBox
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents btnAddTab As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents cbgoogle As System.Windows.Forms.ComboBox
End Class
